// global.angular = require('angular')
require('../dist/index.js');
require('angular-mocks');
