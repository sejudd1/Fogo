
(function (window, angular){
  <%= contents %>
})(window, angular);
